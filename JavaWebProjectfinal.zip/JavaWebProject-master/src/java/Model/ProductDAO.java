/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import Entity.Bill;
import Entity.Product;
import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author DELL
 */
public class ProductDAO {

    Connection conn;

    public ProductDAO(DBConnection db) {
        conn = db.getConnection();
    }
    
    public ArrayList<Product> paging(int PageIndex, int PageSize) {
        try {
            ArrayList<Product> products = new ArrayList<>();
            String sql = "select * from (\n" +
"                         select ROW_NUMBER() over (order by pid ASC) as rn, *\n" +
"                           from Product\n" +
"                        ) as x\n" +
"                        where rn \n" +
"                        between (1-1)*5 +1  \n" +
"                        and 1 * 5";
            PreparedStatement statement = conn.prepareStatement(sql);
            statement.setInt(1, PageIndex);
            statement.setInt(2, PageSize);
            statement.setInt(3, PageIndex);
            statement.setInt(4, PageSize);
            ResultSet rs = statement.executeQuery();
            while(rs.next())
            {
                Product product = new Product();
                product.setP_ID(rs.getInt("pid"));
                product.setName(rs.getString("pname"));
                product.setQuantity(rs.getInt("quantity"));
                product.setPrice(rs.getInt("price"));
                product.setImage(rs.getString("image"));
                product.setDescription(rs.getString("description"));
                product.setCat_ID(rs.getString("catid"));
                
                products.add(product);
            }
            return products;
        } catch (SQLException ex) {
            //Logger.getLogger(DummyDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return null;
    
    }

    public int insertProduct(Product product) {
        int n = 0;
        String sql = "INSERT INTO [Product]\n"
                + "([pname]\n"
                + ",[quantity]\n"
                + ",[price]\n"
                + ",[image]\n"
                + ",[description]\n"
                + ",[catid])\n"
                + "VALUES(?,?,?,?,?,?)";
        try {
            PreparedStatement pre = conn.prepareStatement(sql);
            pre.setString(1, product.getName());
            pre.setInt(2, product.getQuantity());
            pre.setInt(3, product.getPrice());
            pre.setString(4, product.getImage());
            pre.setString(5, product.getDescription());
            pre.setString(6, product.getCat_ID());
         
            n = pre.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(CustomerDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        return n;
    }

    public int updateProduct(String pname, int quantity, int price, String image, String description, String CID,int pid) {
        int n = 0;
        String sql = "UPDATE Product SET pname=?, quantity=?, price=?, image = ? , description= ? , catid = ? where pid = ?";
        try {
            PreparedStatement pre = conn.prepareStatement(sql);
            pre.setString(1, pname);
            pre.setInt(2, quantity);
            pre.setInt(3, price);
            pre.setString(4, image);
            pre.setString(5, description);
            pre.setString(6, CID);
            pre.setInt(7, pid);
                n = pre.executeUpdate();
        } catch (SQLException ex) {
            Logger.getLogger(CustomerDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return n;
    }

    public int deleteCategory(int id) {
        int n = 0;
        //check foreign key: select id in Bill
        String checkSQL = "SELECT * from BillDetail where pid= ?";
        PreparedStatement statement;
        try {
            statement = conn.prepareStatement(checkSQL);
            statement.setInt(1, id);
            ResultSet rs = statement.executeQuery();
            if (rs.next()) {
                return n;
            }

        } catch (SQLException ex) {
            Logger.getLogger(CustomerDAO.class.getName()).log(Level.SEVERE, null, ex);
        }

        String sql = "DELETE FROM Category WHERE pid=" + id;
        try {
            Statement state = conn.createStatement();
            n = state.executeUpdate(sql);
        } catch (SQLException ex) {
            Logger.getLogger(CustomerDAO.class.getName()).log(Level.SEVERE, null, ex);
        }
        return n;
    }
}
